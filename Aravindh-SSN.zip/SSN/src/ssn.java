
import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/ssn")
public class ssn extends HttpServlet
{
	private static final long serialVersionUID = 1L;
 
	double bonus=0.0;
	MathCalculation calculation=new MathCalculation();
	protected void doPost(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException 
	{
		
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		
		String ssnNumber=request.getParameter("ssn");
		String multiplier=request.getParameter("multiplier");
		//-->calling the multiply method in math calculation class
		bonus=calculation.mulitply(Integer.parseInt(multiplier));
		
        out.println("<html>");
        out.println("<head>");
        out.println("<title>Multilplier Result</title>");            
        out.println("</head>");
        out.println("<body>");
        out.println("<p>Bonus Calculation</p>");   
        out.println("<P>Social Security Number is  " +ssnNumber+ "<P>");
        out.println("<P>Multiplier is  " +multiplier+ "<P>");
        out.println("<P>Bonus Amount  is  " +bonus+ "<P>");
        out.println("</body>");
        out.println("</html>");
	}
}
