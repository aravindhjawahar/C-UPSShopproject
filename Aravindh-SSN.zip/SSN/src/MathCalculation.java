
public class MathCalculation
{
	double multiply;

	public  double mulitply(int multiplier)
	{	
		this.multiply=100* multiplier;
		return multiply;
	}
}
