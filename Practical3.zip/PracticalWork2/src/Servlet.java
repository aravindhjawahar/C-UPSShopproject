import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.bean.Bean;
import com.bean.Beans;

public class Servlet extends HttpServlet 
{
	private static final long serialVersionUID = 1L;  
	public Beans beans;
    @Override
    public void init() throws ServletException 
    {
    	super.init();
		beans=new Beans();
    }
	private void checkInput(String ssnNumber,String multiplier )
	{
		Bean bean=new Bean();
		bean.socialSecurityNumber=ssnNumber;
		if( multiplier == "" )
		{
			bean.inputMultiplier=0;
		}
		else
		{
			bean.inputMultiplier=Integer.parseInt(multiplier);
		}
		bean.multiply();
		beans.addBean(bean);
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 		
	{
		
		response.setContentType("text/html");
		
		String ssnNumber1=request.getParameter("ssn1");
		String multiplier1=request.getParameter("multiplier1");
		
		String ssnNumber2=request.getParameter("ssn2");
		String multiplier2=request.getParameter("multiplier2");
		
		String ssnNumber3=request.getParameter("ssn3");
		String multiplier3=request.getParameter("multiplier3");
		
		checkInput(ssnNumber1, multiplier1);
		checkInput(ssnNumber2, multiplier2);
		checkInput(ssnNumber3, multiplier3);
	
		request.getSession().setAttribute("beanValue", this.beans.beans);
		request.getRequestDispatcher("Welcome.jsp").forward(request, response);
	}
}