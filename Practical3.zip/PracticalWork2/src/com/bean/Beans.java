package com.bean;

import java.util.ArrayList;
import java.util.List;

public class Beans 
{
    List<String> ls=new  ArrayList<String>();
	public ArrayList<Bean> beans;
	public Beans()
	{
		this.beans=new ArrayList<Bean>();
	}
	public void addBean(Bean bean)
	{
		this.beans.add(bean);
	}
}
