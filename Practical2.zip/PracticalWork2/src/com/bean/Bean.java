package com.bean;

public class Bean
{
	public String socialSecurityNumber;
	public double bonusAmount;
	public int inputMultiplier;
	
	public String getSocialSecurityNumber() {
		return socialSecurityNumber;
	}
	public void setSocialSecurityNumber(String socialSecurityNumber) {
		this.socialSecurityNumber = socialSecurityNumber;
	}
	public double getBonusAmount() {
		return bonusAmount;
	}
	public void setBonusAmount(double bonusAmount) {
		this.bonusAmount = bonusAmount;
	}
	public int getInputmultiplier() {
		return inputMultiplier;
	}
	public void setInputmultiplier(int inputmultiplier) {
		this.inputMultiplier = inputmultiplier;
	}
	public void multiply()
	{
		this.bonusAmount=this.inputMultiplier*100;
	}
	public Bean getBeanData()
	{
		return this;
	}
}
