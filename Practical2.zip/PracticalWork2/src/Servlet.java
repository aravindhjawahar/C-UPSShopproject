import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.bean.Bean;

public class Servlet extends HttpServlet 
{
	private static final long serialVersionUID = 1L;
       
	Bean bean=new Bean();
	private void checkInput(String ssnNumber,String multiplier )
	{
		if( ssnNumber == "" )
		{
			this.bean.socialSecurityNumber="0";
		}
		else
		{
			this.bean.socialSecurityNumber=ssnNumber;	
		}
		if( multiplier == "" )
		{
			this.bean.inputMultiplier=0;
		}
		else
		{
			this.bean.inputMultiplier=Integer.parseInt(multiplier);
		}
		this.bean.multiply();
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException 		
	{
		response.setContentType("text/html");
		String ssnNumber=request.getParameter("ssn");
		String multiplier=request.getParameter("multiplier");
		checkInput(ssnNumber, multiplier);
		
		request.setAttribute("Beanvalue", this.bean);
		request.getRequestDispatcher("Welcome.jsp").forward(request, response);
	}

}
